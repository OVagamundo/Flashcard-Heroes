class_name SlotView
extends PanelContainer

const InputUtils = preload("res://scripts/InputUtils.gd")
const AnimationConstants = preload("res://scripts/animations/AnimationConstants.gd")
const SLOT_TEXTURE = preload("res://assets/Realistic/ui/textures/slot.png")
const BATTLE_SLOT_TEXTURE = preload("res://assets/Realistic/ui/textures/slotBattle.png")
const BURN_SLOT_TEXTURE = preload("res://assets/Realistic/ui/textures/slotBurn.png")
const LIGHTNING_SLOT_TEXTURE = preload("res://assets/Realistic/ui/textures/slotlightning.png")
const DEATH_SLOT_TEXTURE = preload("res://assets/Realistic/ui/textures/slotDeath.png")
const DEATH_SLOT_OVERLAY_TEXTURE = preload("res://assets/Realistic/ui/textures/slotX.png")

var _location: LocationIdentifier

# InteractionContext properties
var _interaction_mode: StringName = &"FULLY_INTERACTIVE"
var _window_group_id: int = 0

# Size scale for gachaball views (2.0 for battle, 1.0 for windows)
var _size_scale: float = 2.0 # Default to battle scale

# Indicator overlay for valid drop targets
var _indicator: TextureRect = null
var _indicator_tween: Tween = null
const INDICATOR_TEXTURE = preload("res://assets/Realistic/ui/textures/Indicator.png")
var _slot_effect_overlay: TextureRect = null
var _slot_effect_pulse_tween: Tween = null
var _slot_effect_transition_tween: Tween = null
# Base slot size at 1x scale
const BASE_SLOT_SIZE: int = 96

# Slot background stylebox
var _background_style: StyleBoxTexture

## Set size scale for gachaball views in this slot
## NOTE: This only sets internal scale for GachaBallView. Caller is responsible for slot size.
func set_size_scale(size_scale: float) -> void:
	_size_scale = size_scale

func _ready() -> void:
	# Reset node modulation to ensure transparency isn't coming from scene state
	self.modulate = Color.WHITE
	self.self_modulate = Color.WHITE
	
	# Configure the slot background using properties to render the texture
	_background_style = StyleBoxTexture.new()
	_background_style.texture = ArtStyleManager.get_themed_texture(SLOT_TEXTURE)
	# Default neutral tint (no alpha changes as requested)
	_background_style.modulate_color = Color(0.5, 0.5, 0.5)
	add_theme_stylebox_override("panel", _background_style)
	
	# Connect to granular stat change signal for targeted updates
	SignalBus.unit_stat_changed.connect(_on_unit_stat_changed)
	
	# Connect to slot indicator signals
	SignalBus.show_slot_indicators.connect(_on_show_slot_indicators)
	SignalBus.hide_slot_indicators.connect(_on_hide_slot_indicators)
	
	# Create indicator overlay (initially hidden)
	_create_indicator()
	_create_slot_effect_overlay()

## Set custom color for this slot based on container type
var _slot_effect: StringName = &""
var _container_name: StringName = &""

## Set custom color for this slot based on container type
func set_slot_color(container_name: StringName) -> void:
	_container_name = container_name
	_update_slot_appearance()

func set_slot_effect(effect: StringName) -> void:
	var previous_effect := _slot_effect
	_slot_effect = effect
	var should_animate := is_inside_tree() and previous_effect != effect
	_update_slot_appearance(should_animate)

func _update_slot_appearance(animate_transition: bool = false) -> void:
	if not is_instance_valid(_background_style):
		return
	
	# Determine if this is a battle slot
	var is_battle_slot = (_container_name == &"PlayerLineup" or _container_name == &"EnemyLineup" or _container_name == &"PlayerBench" or _container_name == &"EnemyBench" or _container_name == &"EnemyTrinkets" or _container_name == &"PlayerTrinkets")
	
	if _slot_effect == &"burn" and is_battle_slot:
		_background_style.texture = ArtStyleManager.get_themed_texture(BURN_SLOT_TEXTURE)
		_background_style.expand_margin_top = (40.0 * _size_scale) + 15.0
		_background_style.expand_margin_bottom = -15.0
		_background_style.modulate_color = Color.WHITE
	elif _slot_effect == &"lightning" and is_battle_slot:
		_background_style.texture = ArtStyleManager.get_themed_texture(LIGHTNING_SLOT_TEXTURE)
		_background_style.expand_margin_top = (40.0 * _size_scale) + 15.0
		_background_style.expand_margin_bottom = -15.0
		_background_style.modulate_color = Color.WHITE
	elif _slot_effect == &"death" and is_battle_slot:
		_background_style.texture = ArtStyleManager.get_themed_texture(DEATH_SLOT_TEXTURE)
		_background_style.expand_margin_top = (40.0 * _size_scale) + 15.0
		_background_style.expand_margin_bottom = -15.0
		_background_style.modulate_color = Color.WHITE
	else:
		if is_battle_slot:
			_background_style.texture = ArtStyleManager.get_themed_texture(BATTLE_SLOT_TEXTURE)
			# Expand the top margin instead so the base stays at the bottom to touch the unit's feet
			# Shift the slot up by 15px via a negative bottom margin, compensating at the top to preserve ratio
			_background_style.expand_margin_top = (40.0 * _size_scale) + 15.0
			_background_style.expand_margin_bottom = -15.0
		elif _container_name == &"EquippedItem": # C.CONTAINER_EQUIPPED_ITEM
			_background_style.texture = ArtStyleManager.get_themed_texture(load("res://assets/Realistic/ui/textures/ItemSlot.png"))
			_background_style.expand_margin_bottom = 0.0
		else:
			_background_style.texture = ArtStyleManager.get_themed_texture(load("res://assets/Realistic/ui/textures/slot.png"))
			_background_style.expand_margin_bottom = 0.0
			
		# Tint the slot background texture based on container type
		match _container_name:
			&"PlayerLineup":
				_background_style.modulate_color = Color(0.3, 0.5, 0.8)
			&"PlayerBench":
				_background_style.modulate_color = Color(0.3, 0.7, 0.3)
			&"EnemyLineup":
				_background_style.modulate_color = Color(0.8, 0.3, 0.3)
			_:
				_background_style.modulate_color = Color(0.5, 0.5, 0.5)
	
	_update_slot_effect_overlay(animate_transition and _slot_effect == &"death")

func animate_slot_effect_change(effect: StringName) -> void:
	var previous_effect := _slot_effect
	_slot_effect = effect
	_update_slot_appearance(previous_effect != effect)
	if is_instance_valid(_slot_effect_transition_tween):
		await _slot_effect_transition_tween.finished
	else:
		await get_tree().process_frame

func _update_slot_effect_overlay(play_transition: bool) -> void:
	if not is_instance_valid(_slot_effect_overlay):
		return
	
	var is_death_slot := _slot_effect == &"death"
	if is_death_slot:
		_slot_effect_overlay.texture = ArtStyleManager.get_themed_texture(DEATH_SLOT_OVERLAY_TEXTURE)
		_slot_effect_overlay.visible = true
		_slot_effect_overlay.pivot_offset = _slot_effect_overlay.size / 2.0
		if play_transition:
			_play_death_slot_transition()
		else:
			_slot_effect_overlay.modulate = Color(1, 1, 1, 0.9)
			_slot_effect_overlay.scale = Vector2.ONE
			_start_slot_effect_pulse()
	else:
		_slot_effect_overlay.visible = false
		if is_instance_valid(_slot_effect_pulse_tween):
			_slot_effect_pulse_tween.kill()
			_slot_effect_pulse_tween = null
		if is_instance_valid(_slot_effect_transition_tween):
			_slot_effect_transition_tween.kill()
			_slot_effect_transition_tween = null

func _play_death_slot_transition() -> void:
	if not is_instance_valid(_slot_effect_overlay):
		return
	
	if is_instance_valid(_slot_effect_pulse_tween):
		_slot_effect_pulse_tween.kill()
		_slot_effect_pulse_tween = null
	if is_instance_valid(_slot_effect_transition_tween):
		_slot_effect_transition_tween.kill()
	
	_slot_effect_overlay.visible = true
	_slot_effect_overlay.modulate = Color(1, 1, 1, 0.0)
	_slot_effect_overlay.scale = Vector2(0.72, 0.72)
	_slot_effect_transition_tween = create_tween()
	_slot_effect_transition_tween.tween_property(_slot_effect_overlay, "modulate:a", 0.9, AnimationConstants.scaled(0.16)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	_slot_effect_transition_tween.parallel().tween_property(_slot_effect_overlay, "scale", Vector2(1.12, 1.12), AnimationConstants.scaled(0.22)).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_slot_effect_transition_tween.tween_property(_slot_effect_overlay, "scale", Vector2.ONE, AnimationConstants.scaled(0.12)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_slot_effect_transition_tween.finished.connect(_start_slot_effect_pulse, CONNECT_ONE_SHOT)


func _exit_tree() -> void:
	if SignalBus.unit_stat_changed.is_connected(_on_unit_stat_changed):
		SignalBus.unit_stat_changed.disconnect(_on_unit_stat_changed)
	if SignalBus.show_slot_indicators.is_connected(_on_show_slot_indicators):
		SignalBus.show_slot_indicators.disconnect(_on_show_slot_indicators)
	if SignalBus.hide_slot_indicators.is_connected(_on_hide_slot_indicators):
		SignalBus.hide_slot_indicators.disconnect(_on_hide_slot_indicators)

	# If a drag is active while this slot is being freed, end it ONLY if we are the source.
	# This prevents closing windows (which frees their slots) from killing unrelated drags.
	if GlobalInteractionRouter.is_drag_active():
		var context = GlobalInteractionRouter.get_drag_origin_context()
		if context and context.source_view_instance_id:
			# Check if the drag source is one of our children
			for child in get_children():
				if child.get_instance_id() == context.source_view_instance_id:
					GlobalInteractionRouter.end_drag(false)
					GlobalInteractionRouter.end_drag_visuals(false)
					break
	
	# Stop any running indicator tween
	if is_instance_valid(_indicator_tween):
		_indicator_tween.kill()
	if is_instance_valid(_slot_effect_pulse_tween):
		_slot_effect_pulse_tween.kill()
	if is_instance_valid(_slot_effect_transition_tween):
		_slot_effect_transition_tween.kill()

func _notification(_what) -> void:
	pass

# --- Indicator Overlay Methods ---

## Create the indicator overlay (called in _ready)
func _create_indicator() -> void:
	_indicator = TextureRect.new()
	_indicator.texture = ArtStyleManager.get_themed_texture(INDICATOR_TEXTURE)
	_indicator.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_indicator.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_indicator.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_indicator.set_meta("slot_persistent_child", true)
	_indicator.visible = false
	_indicator.z_index = 10 # Ensure it's on top
	
	# Set anchors to fill parent
	_indicator.set_anchors_preset(Control.PRESET_FULL_RECT)
	_indicator.set_offsets_preset(Control.PRESET_FULL_RECT)
	
	add_child(_indicator)

func _create_slot_effect_overlay() -> void:
	_slot_effect_overlay = TextureRect.new()
	_slot_effect_overlay.texture = ArtStyleManager.get_themed_texture(DEATH_SLOT_OVERLAY_TEXTURE)
	_slot_effect_overlay.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_slot_effect_overlay.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_slot_effect_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_slot_effect_overlay.set_meta("slot_persistent_child", true)
	_slot_effect_overlay.visible = false
	_slot_effect_overlay.z_index = 20
	_slot_effect_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_slot_effect_overlay.set_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_slot_effect_overlay)

## Show indicator if this slot is in the valid locations list
func _on_show_slot_indicators(locations: Array) -> void:
	if not is_instance_valid(_location) or not is_instance_valid(_indicator):
		return
	
	# Check if this slot's location is in the valid targets
	var should_show = false
	for loc in locations:
		if loc is LocationIdentifier:
			if loc.container == _location.container and loc.index == _location.index:
				should_show = true
				break
	
	if should_show:
		_show_indicator()
	else:
		_hide_indicator()

## Hide indicator
func _on_hide_slot_indicators() -> void:
	_hide_indicator()

## Show the indicator with pulse animation
func _show_indicator() -> void:
	if not is_instance_valid(_indicator):
		return
	
	_indicator.visible = true
	_indicator.modulate.a = 0.8
	_indicator.pivot_offset = _indicator.size / 2.0
	
	# Start pulse animation
	_start_pulse_animation()

## Hide the indicator and stop animation
func _hide_indicator() -> void:
	if not is_instance_valid(_indicator):
		return
	
	_indicator.visible = false
	
	# Stop pulse animation
	if is_instance_valid(_indicator_tween):
		_indicator_tween.kill()
		_indicator_tween = null

## Pulse animation - scale oscillates between 0.9 and 1.1
func _start_pulse_animation() -> void:
	if is_instance_valid(_indicator_tween):
		_indicator_tween.kill()
	
	_indicator.scale = Vector2.ONE
	
	_indicator_tween = create_tween()
	_indicator_tween.set_loops()
	_indicator_tween.tween_property(_indicator, "scale", Vector2(1.08, 1.08), 0.5).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	_indicator_tween.tween_property(_indicator, "scale", Vector2(0.95, 0.95), 0.5).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)

func _start_slot_effect_pulse() -> void:
	if not is_instance_valid(_slot_effect_overlay):
		return
	if is_instance_valid(_slot_effect_pulse_tween):
		_slot_effect_pulse_tween.kill()
	
	_slot_effect_overlay.scale = Vector2.ONE
	_slot_effect_overlay.modulate.a = 0.9
	_slot_effect_pulse_tween = create_tween()
	_slot_effect_pulse_tween.set_loops()
	_slot_effect_pulse_tween.tween_property(_slot_effect_overlay, "scale", Vector2(1.08, 1.08), AnimationConstants.scaled(0.45)).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	_slot_effect_pulse_tween.parallel().tween_property(_slot_effect_overlay, "modulate:a", 1.0, AnimationConstants.scaled(0.45)).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	_slot_effect_pulse_tween.tween_property(_slot_effect_overlay, "scale", Vector2(0.96, 0.96), AnimationConstants.scaled(0.45)).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	_slot_effect_pulse_tween.parallel().tween_property(_slot_effect_overlay, "modulate:a", 0.7, AnimationConstants.scaled(0.45)).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)

func populate(loc: LocationIdentifier) -> void:
	self._location = loc
	set_meta("location_identifier", loc) # For InteractionManager and WindowManager

## Set the content of this slot using VisualData
func set_content(visual_data: Dictionary, is_inspectable: bool = true, is_enemy: bool = false) -> GachaBallView:
	# Clear existing content (preserve indicator and background)
	# Clear existing content (preserve indicator)
	for child in get_children():
		if child.has_meta("slot_persistent_child"):
			continue
		child.queue_free()
	
	if visual_data.is_empty():
		return
	
	
	var gacha_ball_view_scene = load("res://scenes/GachaBallView.tscn")
	
	if not is_instance_valid(gacha_ball_view_scene):
		push_error("[SlotView] GachaBallViewScene failed to load!")
		return
		
	var view = gacha_ball_view_scene.instantiate()
	
	if not is_instance_valid(view):
		push_error("[SlotView] Failed to instantiate GachaBallView!")
		return null
	
	# Set size scale before adding to tree (so populate uses correct scale)
	if view.has_method("set_size_scale"):
		view.set_size_scale(_size_scale)
	
	add_child(view)
	
	# Populate the view with visual data
	view.populate(_location, visual_data, is_inspectable)
	var def_id: StringName = visual_data.get("definition_id", &"")
	view.set_is_enemy(is_enemy, def_id)
	
	# Propagate interaction context from SlotView to child GachaBallView
	# Entity type is derived from the visual data category
	var category: StringName = visual_data.get("category", &"UNIT")
	var entity_type: StringName = category # UNIT, ITEM, or TRINKET
	var effective_mode = _interaction_mode
	
	# Force inspection only for enemies unless in specific contexts (handled by slot mode usually)
	# But trusting _interaction_mode from the slot is the correct architectural approach.
	view.set_interaction_context(effective_mode, entity_type, _window_group_id)
	
	# If inspection or selection only, disable dragging functionality (interactive flag controls drag in GachaBallView)
	if effective_mode in [&"INSPECTION_ONLY", &"SELECTION_ONLY"]:
		view.set_is_interactive(false)
	else:
		view.set_is_interactive(true)
	
	view.set_meta("location_identifier", _location)
	
	# If this slot has no location (e.g. Rest Site visual balls), 
	# it shouldn't consume clicks at all. Pass them to the parent.
	if not is_instance_valid(_location):
		_recursively_set_mouse_filter_ignore(view)
	
	return view

## Helper to recursively set mouse filter to ignore
func _recursively_set_mouse_filter_ignore(node: Node) -> void:
	if node is Control:
		node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for child in node.get_children():
		_recursively_set_mouse_filter_ignore(child)


## Granular stat change handler - updates only the specific stat that changed
func _on_unit_stat_changed(unit_uuid: String, stat_name: StringName, old_value: int, new_value: int) -> void:
	# Check if we have a child view that matches this UUID
	for child in get_children():
		if child is GachaBallView and child.get_instance_uuid() == unit_uuid:
			# Delegate to view's granular handler
			if is_instance_valid(child) and child.has_method("_on_unit_stat_changed"):
				child._on_unit_stat_changed(unit_uuid, stat_name, old_value, new_value)
			break


## Configure the interaction context for this slot
func set_interaction_context(interaction_mode: StringName, window_group_id: int = 0) -> void:
	_interaction_mode = interaction_mode
	_window_group_id = window_group_id

## Create and emit InteractionContext for this slot
func _create_interaction_context(event_type: StringName) -> InteractionContext:
	var context = InteractionContext.new()
	context.source_view_instance_id = get_instance_id()
	context.event_type = event_type
	context.location = _location
	context.entity_uuid = "" # Empty slots have no entity
	context.entity_type = &"EMPTY_SLOT"
	context.interaction_mode = _interaction_mode
	context.window_group_id = _window_group_id
	return context

func _has_point(point: Vector2) -> bool:
	var radius = size.x / 2.0
	var center = Vector2(radius, size.y / 2.0)
	return point.distance_to(center) <= radius

func _gui_input(event: InputEvent) -> void:
	# Ignore input entirely if we don't have a location (e.g. visual-only slots in RestSite)
	if not is_instance_valid(_location):
		return

	if InputUtils.is_primary_pointer_press(event):
		# Do NOT consume the event here; allow child views to initiate drag
		# Check for actual content (GachaBallView), ignoring the indicator
		var has_content = false
		for child in get_children():
			if child is GachaBallView:
				has_content = true
				break
		
		# If this is an empty slot (no content), handle the click as EMPTY_SLOT interaction
		if not has_content:
			pass
			var context = _create_interaction_context(&"SINGLE_CLICK")
			SignalBus.emit_signal("interaction_context_received", context)
			get_viewport().set_input_as_handled() # Stop propagation to Main/Battle
			accept_event() # Explicitly stop control bubbling
		else:
			pass
		
		# If we have a child (Unit), we do NOTHING. 
		# The child (GachaBallView) will handle the input itself (emit UNIT context).
		# We must ensure GachaBallView consumes the event (BLOCK/STOP) so it doesn't bubble here.

func _can_drop_data(_at_position, data) -> bool:
	# Check if this is an inspection-only context
	if _interaction_mode == &"INSPECTION_ONLY":
		return false
		
	return data is Dictionary and data.has("source_loc")

func _drop_data(_at_position, _data) -> void:
	# Check if this is an inspection-only context
	if _interaction_mode == &"INSPECTION_ONLY":
		return

	# Create a target interaction context and route via GIR
	var target_ctx = _create_interaction_context(&"DROP")
	
	# IMMEDIATE VISUAL FEEDBACK: Hide indicator now.
	_hide_indicator()
	
	SignalBus.emit_signal("interaction_context_received", target_ctx)
	
	# Do not end drag here; InventoryManager will decide handled/unhandled and
	# call GlobalInteractionRouter.end_drag(true/false) centrally.
